<?php

//Masukkan PHPSESID
$PHPSESSID = "xxxxxxxxxxxxxxxxxxxxxx";

//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/btcgains/ajax.php";

//Masukkan User-Agent
$UA = "Mozilla/5.0 (Linux; Android 9; SM-J610F Build/PPR1.180610.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/74.0.3729.157 Mobile Safari/537.36";

?>
