<?php

//Masukkan PHPSESID
$PHPSESSID = "ehjp63r86qha7p5fgejmu9g383";

//Biarkan Saja URL Ini
$url = "http://affi.cryptoplanets.org/btcgains/ajax.php";

//Masukkan User-Agent
$UA = "Mozilla/5.0 (Linux; Android 5.1; 1201 Build/LMY47I; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/75.0.3770.67 Mobile Safari/537.36";

?>
